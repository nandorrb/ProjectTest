drupalgap.settings = {
  'site_path':'http://66.240.171.71/drupal', /* e.g. http://www.example.com */
  'base_path':'/',
  'language':'und',
  'file_public_path':'sites/default/files',
  'debug':true, /* set to true to see console.log debug information */
  'front':'dashboard.html',
  'offline':'offline.html',
  'clean_urls':false, /* set to true if you have clean urls enabled on your site */
};
drupalgap.modules.custom = [
  /*{'name':'my_module'},*/
];

