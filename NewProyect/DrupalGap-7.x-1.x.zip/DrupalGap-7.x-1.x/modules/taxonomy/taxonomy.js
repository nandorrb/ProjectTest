/**
 * Implements hook_entity_info().
 */
function taxonomy_entity_info() {
  try {
  }
  catch (error) {
    alert('taxonomy_entity_info - ' + error);
  }
}

