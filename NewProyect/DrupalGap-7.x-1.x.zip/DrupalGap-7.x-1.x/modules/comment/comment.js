/**
 * Implements hook_entity_info().
 */
function comment_entity_info() {
  try {
  }
  catch (error) {
    alert('comment_entity_info - ' + error);
  }
}

